import pytest
from pydantic import ValidationError
from app.schemas.product import ProductCreate, ProductUpdate


def test_product_create_accepts_valid_data():
    product = ProductCreate(name=" Mouse ", quantity=5, price=99.9)
    assert product.name == "Mouse"
    assert product.status is True


@pytest.mark.parametrize("payload", [
    {"name": " ", "quantity": 1, "price": 10},
    {"name": "Mouse", "quantity": -1, "price": 10},
    {"name": "Mouse", "quantity": 1, "price": -0.01},
])
def test_product_create_rejects_invalid_data(payload):
    with pytest.raises(ValidationError):
        ProductCreate(**payload)


def test_product_update_rejects_unknown_fields():
    with pytest.raises(ValidationError):
        ProductUpdate(color="red")
