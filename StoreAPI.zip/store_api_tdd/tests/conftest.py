import mongomock
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.controllers.product_controller import get_use_cases
from app.repositories.product_repository import ProductRepository
from app.use_cases.product_use_cases import ProductUseCases


@pytest.fixture
def collection():
    client = mongomock.MongoClient()
    return client["store_api_test"]["products"]


@pytest.fixture
def use_cases(collection):
    return ProductUseCases(ProductRepository(collection))


@pytest.fixture
def api_client(collection):
    def override_use_cases():
        return ProductUseCases(ProductRepository(collection))
    app.dependency_overrides[get_use_cases] = override_use_cases
    with TestClient(app) as client:
        yield client
    app.dependency_overrides.clear()
