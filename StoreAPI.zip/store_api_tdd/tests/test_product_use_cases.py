import time
import pytest
from app.use_cases.product_use_cases import ProductNotFoundError


def sample():
    return {"name": "Notebook", "quantity": 4, "price": 6500.0, "status": True}


def test_create_product_generates_id_and_timestamps(use_cases):
    product = use_cases.create_product(sample())
    assert product["id"]
    assert product["created_at"] == product["updated_at"]


def test_list_products_filters_price_range(use_cases):
    use_cases.create_product({**sample(), "name": "Cheap", "price": 100})
    use_cases.create_product({**sample(), "name": "In range", "price": 6500})
    use_cases.create_product({**sample(), "name": "Expensive", "price": 9000})
    result = use_cases.list_products(min_price=5000, max_price=8000)
    assert [item["name"] for item in result] == ["In range"]


def test_get_product_returns_product(use_cases):
    created = use_cases.create_product(sample())
    assert use_cases.get_product(created["id"])["name"] == "Notebook"


def test_get_product_missing_raises_404_domain_error(use_cases):
    with pytest.raises(ProductNotFoundError):
        use_cases.get_product("000000000000000000000000")


def test_patch_updates_fields_and_updated_at(use_cases):
    created = use_cases.create_product(sample())
    old_updated_at = created["updated_at"]
    time.sleep(0.002)
    updated = use_cases.update_product(created["id"], {"price": 7000.0})
    assert updated["price"] == 7000.0
    assert updated["updated_at"] >= old_updated_at


def test_patch_missing_product_raises_error(use_cases):
    with pytest.raises(ProductNotFoundError):
        use_cases.update_product("000000000000000000000000", {"price": 2})


def test_patch_without_fields_is_rejected(use_cases):
    created = use_cases.create_product(sample())
    with pytest.raises(ValueError):
        use_cases.update_product(created["id"], {})


def test_delete_product_removes_it(use_cases):
    created = use_cases.create_product(sample())
    use_cases.delete_product(created["id"])
    with pytest.raises(ProductNotFoundError):
        use_cases.get_product(created["id"])


def test_delete_missing_product_raises_error(use_cases):
    with pytest.raises(ProductNotFoundError):
        use_cases.delete_product("000000000000000000000000")
