def product_payload():
    return {"name": "Notebook", "quantity": 10, "price": 6500.0, "status": True}


def test_create_product_returns_201(api_client):
    response = api_client.post("/products", json=product_payload())
    assert response.status_code == 201
    assert response.json()["name"] == "Notebook"


def test_create_product_validation_returns_422(api_client):
    response = api_client.post("/products", json={"name": "", "quantity": -1, "price": -5})
    assert response.status_code == 422


def test_list_products_with_price_filter(api_client):
    api_client.post("/products", json=product_payload())
    api_client.post("/products", json={**product_payload(), "name": "Cheap", "price": 100})
    response = api_client.get("/products?min_price=5000&max_price=8000")
    assert response.status_code == 200
    assert len(response.json()) == 1
    assert response.json()[0]["name"] == "Notebook"


def test_get_product_returns_200_and_missing_returns_404(api_client):
    created = api_client.post("/products", json=product_payload()).json()
    assert api_client.get(f"/products/{created['id']}").status_code == 200
    assert api_client.get("/products/000000000000000000000000").status_code == 404
    assert api_client.get("/products/not-an-object-id").status_code == 404


def test_patch_product_updates_and_refreshes_timestamp(api_client):
    created = api_client.post("/products", json=product_payload()).json()
    response = api_client.patch(f"/products/{created['id']}", json={"price": 7200})
    assert response.status_code == 200
    assert response.json()["price"] == 7200
    assert response.json()["updated_at"] >= created["updated_at"]


def test_patch_missing_product_returns_404(api_client):
    response = api_client.patch(
        "/products/000000000000000000000000", json={"price": 10}
    )
    assert response.status_code == 404


def test_delete_product_returns_204(api_client):
    created = api_client.post("/products", json=product_payload()).json()
    response = api_client.delete(f"/products/{created['id']}")
    assert response.status_code == 204
    assert api_client.get(f"/products/{created['id']}").status_code == 404


def test_delete_missing_product_returns_404(api_client):
    response = api_client.delete("/products/000000000000000000000000")
    assert response.status_code == 404


def test_price_min_greater_than_max_returns_422(api_client):
    response = api_client.get("/products?min_price=9000&max_price=1000")
    assert response.status_code == 422
