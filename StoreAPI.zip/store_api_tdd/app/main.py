from fastapi import FastAPI
from app.controllers.product_controller import router as product_router

app = FastAPI(
    title="Store API",
    description="API de produtos desenvolvida com FastAPI, MongoDB e TDD.",
    version="1.0.0",
)

app.include_router(product_router)


@app.get("/health", tags=["Health"])
def health_check():
    return {"status": "ok"}
