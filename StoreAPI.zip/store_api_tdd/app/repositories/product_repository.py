from datetime import datetime, timezone
from bson import ObjectId
from bson.errors import InvalidId
from pymongo.collection import Collection


class ProductRepository:
    def __init__(self, collection: Collection):
        self.collection = collection

    @staticmethod
    def _serialize(document: dict | None):
        if document is None:
            return None
        document["id"] = str(document.pop("_id"))
        return document

    @staticmethod
    def valid_id(product_id: str) -> bool:
        try:
            ObjectId(product_id)
            return True
        except (InvalidId, TypeError):
            return False

    def create(self, data: dict):
        now = datetime.now(timezone.utc)
        document = {**data, "created_at": now, "updated_at": now}
        result = self.collection.insert_one(document)
        document["_id"] = result.inserted_id
        return self._serialize(document)

    def list(self, min_price=None, max_price=None, status=None):
        query = {}
        price_filter = {}
        if min_price is not None:
            price_filter["$gte"] = min_price
        if max_price is not None:
            price_filter["$lte"] = max_price
        if price_filter:
            query["price"] = price_filter
        if status is not None:
            query["status"] = status
        return [self._serialize(item) for item in self.collection.find(query).sort("name", 1)]

    def get(self, product_id: str):
        if not self.valid_id(product_id):
            return None
        return self._serialize(self.collection.find_one({"_id": ObjectId(product_id)}))

    def update(self, product_id: str, data: dict):
        if not self.valid_id(product_id):
            return None
        data["updated_at"] = datetime.now(timezone.utc)
        result = self.collection.find_one_and_update(
            {"_id": ObjectId(product_id)},
            {"$set": data},
            return_document=True,
        )
        return self._serialize(result)

    def delete(self, product_id: str) -> bool:
        if not self.valid_id(product_id):
            return False
        result = self.collection.delete_one({"_id": ObjectId(product_id)})
        return result.deleted_count == 1
