from pymongo import MongoClient
from app.core.config import MONGODB_URL, MONGODB_DATABASE

_client = None


def get_database():
    global _client
    if _client is None:
        _client = MongoClient(MONGODB_URL, serverSelectionTimeoutMS=3000)
    return _client[MONGODB_DATABASE]


def get_products_collection():
    return get_database()["products"]


def close_connection():
    global _client
    if _client is not None:
        _client.close()
        _client = None
