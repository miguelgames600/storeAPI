from app.repositories.product_repository import ProductRepository


class ProductNotFoundError(Exception):
    pass


class ProductUseCases:
    def __init__(self, repository: ProductRepository):
        self.repository = repository

    def create_product(self, data: dict):
        return self.repository.create(data)

    def list_products(self, min_price=None, max_price=None, status=None):
        if min_price is not None and max_price is not None and min_price > max_price:
            raise ValueError("min_price não pode ser maior que max_price.")
        return self.repository.list(min_price=min_price, max_price=max_price, status=status)

    def get_product(self, product_id: str):
        product = self.repository.get(product_id)
        if product is None:
            raise ProductNotFoundError("Produto não encontrado.")
        return product

    def update_product(self, product_id: str, data: dict):
        changes = {key: value for key, value in data.items() if value is not None}
        if not changes:
            raise ValueError("Informe ao menos um campo para atualizar.")
        product = self.repository.update(product_id, changes)
        if product is None:
            raise ProductNotFoundError("Produto não encontrado.")
        return product

    def delete_product(self, product_id: str):
        if not self.repository.delete(product_id):
            raise ProductNotFoundError("Produto não encontrado.")
