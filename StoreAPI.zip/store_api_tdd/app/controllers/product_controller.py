from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from pymongo.errors import PyMongoError
from app.database.mongo import get_products_collection
from app.repositories.product_repository import ProductRepository
from app.schemas.product import ProductCreate, ProductUpdate, ProductResponse
from app.use_cases.product_use_cases import ProductUseCases, ProductNotFoundError

router = APIRouter(prefix="/products", tags=["Products"])


def get_use_cases():
    return ProductUseCases(ProductRepository(get_products_collection()))


@router.post("", response_model=ProductResponse, status_code=status.HTTP_201_CREATED)
def create_product(payload: ProductCreate, use_cases: ProductUseCases = Depends(get_use_cases)):
    try:
        return use_cases.create_product(payload.model_dump())
    except PyMongoError:
        raise HTTPException(status_code=500, detail="Não foi possível cadastrar o produto.")


@router.get("", response_model=list[ProductResponse])
def list_products(
    min_price: float | None = Query(default=None, ge=0),
    max_price: float | None = Query(default=None, ge=0),
    status_filter: bool | None = Query(default=None, alias="status"),
    use_cases: ProductUseCases = Depends(get_use_cases),
):
    try:
        return use_cases.list_products(min_price=min_price, max_price=max_price, status=status_filter)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except PyMongoError:
        raise HTTPException(status_code=500, detail="Não foi possível consultar os produtos.")


@router.get("/{product_id}", response_model=ProductResponse)
def get_product(product_id: str, use_cases: ProductUseCases = Depends(get_use_cases)):
    try:
        return use_cases.get_product(product_id)
    except ProductNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except PyMongoError:
        raise HTTPException(status_code=500, detail="Não foi possível consultar o produto.")


@router.patch("/{product_id}", response_model=ProductResponse)
def update_product(
    product_id: str,
    payload: ProductUpdate,
    use_cases: ProductUseCases = Depends(get_use_cases),
):
    try:
        return use_cases.update_product(product_id, payload.model_dump(exclude_unset=True))
    except ProductNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except PyMongoError:
        raise HTTPException(status_code=500, detail="Não foi possível atualizar o produto.")


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_product(product_id: str, use_cases: ProductUseCases = Depends(get_use_cases)):
    try:
        use_cases.delete_product(product_id)
        return Response(status_code=status.HTTP_204_NO_CONTENT)
    except ProductNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except PyMongoError:
        raise HTTPException(status_code=500, detail="Não foi possível excluir o produto.")
