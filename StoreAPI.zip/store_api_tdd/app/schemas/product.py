from datetime import datetime, timezone
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator


class ProductCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    quantity: int = Field(ge=0)
    price: float = Field(ge=0)
    status: bool = True

    @field_validator("name")
    @classmethod
    def name_must_not_be_blank(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("O nome do produto não pode ficar vazio.")
        return value


class ProductUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    quantity: Optional[int] = Field(default=None, ge=0)
    price: Optional[float] = Field(default=None, ge=0)
    status: Optional[bool] = None

    @field_validator("name")
    @classmethod
    def name_must_not_be_blank(cls, value):
        if value is not None:
            value = value.strip()
            if not value:
                raise ValueError("O nome do produto não pode ficar vazio.")
        return value

    model_config = ConfigDict(extra="forbid")


class ProductResponse(BaseModel):
    id: str
    name: str
    quantity: int
    price: float
    status: bool
    created_at: datetime
    updated_at: datetime
