# Store API — FastAPI + MongoDB + TDD

API educacional de produtos, desenvolvida com FastAPI, Pydantic, MongoDB e Pytest, seguindo o ciclo **Red → Green → Refactor**.

## Funcionalidades

- Criar, listar, consultar, atualizar parcialmente e excluir produtos.
- Validar entradas e saídas com Pydantic.
- Filtrar produtos por faixa de preço (`min_price` e `max_price`).
- Atualizar `updated_at` automaticamente no PATCH.
- Retornar 404 quando o produto não existe.
- Tratar erros de persistência sem expor detalhes internos.
- Testes automatizados de schemas, casos de uso e endpoints.
- MongoDB local via Docker Compose.

## Modelo de produto

| Campo | Tipo | Regra |
|---|---|---|
| `id` | string | Gerado pelo MongoDB (ObjectId) |
| `name` | string | Obrigatório, não vazio |
| `quantity` | inteiro | Maior ou igual a zero |
| `price` | número | Maior ou igual a zero |
| `status` | booleano | Padrão `true` |
| `created_at` | datetime | Gerado na criação |
| `updated_at` | datetime | Atualizado em cada PATCH |

## Estrutura

```text
store_api_tdd/
├── app/
│   ├── controllers/
│   │   └── product_controller.py
│   ├── core/
│   │   └── config.py
│   ├── database/
│   │   └── mongo.py
│   ├── repositories/
│   │   └── product_repository.py
│   ├── schemas/
│   │   └── product.py
│   ├── use_cases/
│   │   └── product_use_cases.py
│   └── main.py
├── tests/
│   ├── conftest.py
│   ├── test_product_schemas.py
│   ├── test_product_use_cases.py
│   └── test_product_controller.py
├── .env.example
├── .gitignore
├── docker-compose.yml
├── requirements.txt
└── pytest.ini
```

## 1. Requisitos

- Python 3.11 ou superior
- Docker Desktop (recomendado) ou MongoDB instalado localmente
- Git (opcional, para publicar no GitHub)

## 2. Preparar o ambiente

Abra a pasta do projeto no VS Code. No terminal, execute:

### Windows (PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Se o PowerShell bloquear a ativação, execute uma vez:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

Feche e abra o terminal e ative o ambiente novamente.

### Linux / macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

## 3. Iniciar o MongoDB

Com Docker Desktop aberto, na pasta do projeto:

```bash
docker compose up -d
```

O MongoDB ficará disponível em `mongodb://localhost:27017` e os dados serão persistidos no volume `mongo_data`.

Sem Docker, instale o MongoDB Community Server e ajuste `MONGODB_URL` no arquivo `.env`.

## 4. Executar os testes (TDD)

Com o ambiente virtual ativado:

```bash
pytest -v
```

Para ver a cobertura:

```bash
pytest --cov=app --cov-report=term-missing
```

Os testes usam `mongomock`, portanto **não precisam de um MongoDB real ligado**.

### Como o TDD foi organizado

1. **Red:** os testes em `tests/` descrevem primeiro o comportamento esperado.
2. **Green:** schemas, casos de uso, repositório e controller implementam o comportamento.
3. **Refactor:** responsabilidades separadas em camadas, validações centralizadas e tratamento consistente de erros.

Para praticar o ciclo, escolha um teste, comente temporariamente a implementação correspondente, execute `pytest` e observe a falha. Depois implemente até ficar verde e refatore.

## 5. Iniciar a API

```bash
uvicorn app.main:app --reload
```

Acesse:

- Swagger: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc
- Health check: http://127.0.0.1:8000/health

## 6. Endpoints

| Método | Rota | Descrição |
|---|---|---|
| POST | `/products` | Cadastra produto |
| GET | `/products` | Lista produtos |
| GET | `/products/{id}` | Busca por ID |
| PATCH | `/products/{id}` | Atualiza parcialmente |
| DELETE | `/products/{id}` | Exclui produto |

### Criar produto

`POST /products`

```json
{
  "name": "Notebook",
  "quantity": 10,
  "price": 6500.00,
  "status": true
}
```

Resposta: `201 Created`.

### Listar e filtrar

`GET /products`

- `min_price`: preço mínimo (inclusivo).
- `max_price`: preço máximo (inclusivo).
- `status`: filtra por ativo/inativo.

Exemplos:

```text
GET /products
GET /products?min_price=5000&max_price=8000
GET /products?min_price=5000&max_price=8000&status=true
```

Para reproduzir a faixa estrita citada no desafio (maior que 5.000 e menor que 8.000), use:

```text
GET /products?min_price=5000.01&max_price=7999.99
```

A listagem retorna uma lista JSON.

### Buscar por ID

`GET /products/{id}`

ID inválido ou produto inexistente: `404 Not Found`.

### Atualizar produto

`PATCH /products/{id}`

Envie somente os campos que deseja alterar:

```json
{
  "price": 7200.00,
  "quantity": 8
}
```

O campo `updated_at` é atualizado automaticamente. Produto inexistente: `404 Not Found`.

### Excluir produto

`DELETE /products/{id}`

Resposta: `204 No Content`. Produto inexistente: `404 Not Found`.

## 7. Respostas de erro

- `422 Unprocessable Entity`: corpo ou parâmetros inválidos (validação do FastAPI/Pydantic).
- `404 Not Found`: ID inválido ou produto não encontrado.
- `500 Internal Server Error`: falha inesperada de persistência; a resposta não revela detalhes internos.

## 8. Variáveis de ambiente

Edite `.env` se necessário:

```env
MONGODB_URL=mongodb://localhost:27017
MONGODB_DATABASE=store_api
```

## 9. Publicar no GitHub

1. Extraia o ZIP.
2. Crie um repositório vazio no GitHub.
3. Abra a pasta extraída no VS Code.
4. No terminal, execute:

```bash
git init
git add .
git commit -m "feat: implement Store API with FastAPI and TDD"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
git push -u origin main
```

Troque a URL pela URL do seu repositório.

## Observações

- O projeto usa MongoDB e `pymongo` síncrono para manter a implementação didática e simples.
- Os testes isolam o banco com `mongomock`.
- Não envie seu arquivo `.env` ao GitHub. O `.env.example` é seguro para publicar.
